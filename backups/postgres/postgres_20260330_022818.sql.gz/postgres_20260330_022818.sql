--
-- PostgreSQL database cluster dump
--

\restrict OjwuFFqOIjaqMGh4CRWGPJYfJJo2glN1mJY2OzaoDSxCMT82HXEAtMoFtH5YMVs

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE odoo;
ALTER ROLE odoo WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:5IlQqfxxe9ICBwPHfG76tw==$zAbopc9k3Q93FYI+8dg6SbvTx9bxhU3pfkNIlQD1R+M=:0f+OZhDBxLLetuOSbTxjPaPHgIDWa6+/e4Yshjh4sms=';

--
-- User Configurations
--








\unrestrict OjwuFFqOIjaqMGh4CRWGPJYfJJo2glN1mJY2OzaoDSxCMT82HXEAtMoFtH5YMVs

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict O9TPr12yKcn1si8reEmwxtp5kgxk7iY6dMxTyLcXWq54v6uA7yb1BV0cawECSvw

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict O9TPr12yKcn1si8reEmwxtp5kgxk7iY6dMxTyLcXWq54v6uA7yb1BV0cawECSvw

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict OAZFpuc1wYVlNrqQ0zOvmXKcbXzrO0uYuOUMkQ465sW0zpPH0RlgfiVRBDUcKKn

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict OAZFpuc1wYVlNrqQ0zOvmXKcbXzrO0uYuOUMkQ465sW0zpPH0RlgfiVRBDUcKKn

--
-- PostgreSQL database cluster dump complete
--

