--
-- PostgreSQL database cluster dump
--

\restrict zPIItsY1hF4hKuZcXU4UUfoXsOyW1ZX7f8MCRcktPg6KqW7ppxi98XvcU7b1o6S

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE odoo;
ALTER ROLE odoo WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:5IlQqfxxe9ICBwPHfG76tw==$zAbopc9k3Q93FYI+8dg6SbvTx9bxhU3pfkNIlQD1R+M=:0f+OZhDBxLLetuOSbTxjPaPHgIDWa6+/e4Yshjh4sms=';

--
-- User Configurations
--








\unrestrict zPIItsY1hF4hKuZcXU4UUfoXsOyW1ZX7f8MCRcktPg6KqW7ppxi98XvcU7b1o6S

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict dd10TizK7FMgVxg9xB2pVFch4roXq044iMcfcwuY2aXkoUYTxv7HrtxiiAMTIom

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict dd10TizK7FMgVxg9xB2pVFch4roXq044iMcfcwuY2aXkoUYTxv7HrtxiiAMTIom

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict mpg9sr3InNZgmrd5oUyh4z7Jxhf2dJk8aRoag2Mz7aPxXh2MxM8ztBcGMYFUdw3

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict mpg9sr3InNZgmrd5oUyh4z7Jxhf2dJk8aRoag2Mz7aPxXh2MxM8ztBcGMYFUdw3

--
-- PostgreSQL database cluster dump complete
--

